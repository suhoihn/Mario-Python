<?xml version="1.0" encoding="UTF-8"?>
<tileset name="intro" tilewidth="16" tileheight="16">
 <properties>
  <property name="hide_hud" value="true"/>
  <property name="music" value="priest"/>
 </properties>
 <image source="intro.png" width="16" height="16"/>
 <tile id="0">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
</tileset>
