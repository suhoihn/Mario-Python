<?xml version="1.0" encoding="UTF-8"?>
<tileset name="lttp" tilewidth="16" tileheight="16">
 <properties>
  <property name="frames" value="3"/>
  <property name="interval" value="0.7"/>
  <property name="intro" value="overworld_intro"/>
  <property name="music" value="overworld"/>
 </properties>
 <image source="lttp.png" trans="ff40ff" width="576" height="576"/>
 <tile id="8">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="9">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="10">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="14">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="15">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="16">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="17">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="36">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="37">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="38">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="39">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="40">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="41">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="43">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="44">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="45">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="46">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="47">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="50">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="51">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="72">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="73">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="75">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="76">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="78">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="79">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="80">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="81">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="82">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="83">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="84">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="86">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="87">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="108">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="109">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="110">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="111">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="112">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="113">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="114">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="120">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="121">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="122">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="123">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="124">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="138">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="143">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="145">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="146">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="147">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="149">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="150">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="156">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="157">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="158">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="159">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="160">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="174">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="179">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="182">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="186">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="192">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="194">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="195">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="196">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="201">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="210">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="215">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="220">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="221">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="223">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="224">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="225">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="226">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="227">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="230">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="231">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="232">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="237">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="248">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="249">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="256">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="257">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="284">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="285">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="288">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="289">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="290">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="291">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="292">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="293">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="294">
  <properties>
   <property name="animated" value="true"/>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="295">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="296">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="320">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="321">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="324">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="325">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="326">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="327">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="328">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="329">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="330">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="331">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="332">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="335">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="336">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="337">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="338">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="360">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="361">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="362">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="363">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="364">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="365">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="366">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="367">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="368">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="370">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="371">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="374">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="375">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="396">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="397">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="398">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="402">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="403">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="404">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="405">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="406">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="411">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="412">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="432">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="433">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="434">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="438">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="439">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="440">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="441">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="442">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="443">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="446">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="447">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="448">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="468">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="469">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="470">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="474">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="475">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="476">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="477">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="478">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="479">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="480">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="481">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="482">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="483">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="484">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="504">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="505">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="506">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="507">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="508">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="509">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="510">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="511">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="512">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="514">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="515">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="516">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="517">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="518">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="519">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="540">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="541">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="542">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="543">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="544">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="545">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="546">
  <properties>
   <property name="animated" value="true"/>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="547">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="548">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="551">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="552">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="553">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="554">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="576">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="577">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="578">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="579">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="580">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="581">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="582">
  <properties>
   <property name="animated" value="true"/>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="583">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="584">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="588">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="589">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="612">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="613">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="614">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="615">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="616">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="617">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="618">
  <properties>
   <property name="animated" value="true"/>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="619">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="620">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="701">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="745">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="746">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="747">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="748">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="781">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="782">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="783">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="784">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="795">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="796">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="803">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="804">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="805">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="817">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="818">
  <properties>
   <property name="above" value="true"/>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="819">
  <properties>
   <property name="above" value="true"/>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="820">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="831">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="832">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="833">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="834">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="839">
  <properties>
   <property name="above" value="true"/>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="840">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="841">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="842">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="843">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="844">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="854">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="855">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="869">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="870">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="875">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="876">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="877">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="878">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="879">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="880">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="911">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="912">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="913">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="914">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="915">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="916">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="917">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="918">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="919">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="920">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="921">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="922">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="953">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="954">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="955">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="956">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="957">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="958">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="991">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="992">
  <properties>
   <property name="above" value="true"/>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="993">
  <properties>
   <property name="above" value="true"/>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="994">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="1028">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1029">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1036">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1044">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1045">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1046">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1047">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1048">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1050">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1051">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1052">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1072">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1080">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1081">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1082">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1083">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1084">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1085">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1086">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1087">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1088">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1089">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1090">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1116">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1117">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1118">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1119">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1121">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1122">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1123">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1124">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1125">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1126">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1141">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="1142">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="1143">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="1177">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="1178">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="1179">
  <properties>
   <property name="above" value="true"/>
  </properties>
 </tile>
 <tile id="1210">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="1246">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
</tileset>
