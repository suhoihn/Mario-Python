#include "debug.hpp"

bool Debug::enabled = false;
