
class Debug {
public:
    static bool enabled;
};