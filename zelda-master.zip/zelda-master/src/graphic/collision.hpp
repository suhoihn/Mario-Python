enum Collision {
    NONE, BLOCK, DAMAGE, ATTACK, SHIELD
};
