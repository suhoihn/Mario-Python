#pragma once

#include "../level_events.hpp"

class DungeonBoss : public LevelEvents {
public:
    DungeonBoss();
};