#pragma once

#include "../level_events.hpp"

class Intro : public LevelEvents {
public:
    Intro();
};