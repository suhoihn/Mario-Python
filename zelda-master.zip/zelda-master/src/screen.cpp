#include "screen.hpp"

Screen::Screen()
{}

void Screen::Init() {
  // Do nothing
}
