#include <GL/gl.h>

double CurrentTime();
GLuint LoadTexture(const char* path);
