# zeldaGame
Progress on a throwback Zelda clone with Pygame. Move with arrow keys, transform into wolf with w key, pickup items by walking over them, drop equipped weapon with spacebar.

> $ pip3 install -r requirements.txt

> $ python3 main.py


